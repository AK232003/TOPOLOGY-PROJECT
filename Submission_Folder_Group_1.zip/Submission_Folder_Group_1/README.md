# TOPOLOGY-PROJECT
We used Boundary Matrix Method to calculate the Betti 0.

# Pre-Requisites
You Need to have a python library named sympy already installed on the system.
You can download it by running the command "pip3 install sympt" on linux terminal.
